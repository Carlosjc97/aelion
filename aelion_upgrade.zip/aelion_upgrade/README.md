# Aelion

![CI](https://github.com/Carlosjc97/aelion/actions/workflows/ci.yml/badge.svg)

Aelion es una aplicación de aprendizaje dirigida a usuarios que desean
aprender de manera rápida y adaptativa.  Combina microaprendizaje, práctica
de idiomas y un solucionador de problemas basado en IA en una experiencia
unificada con gamificación, accesibilidad e internacionalización.

## Características

* **Toma un curso** – Busca un tema, realiza un test diagnóstico generado
  dinámicamente y sigue un curso modularizado en lecciones de cinco minutos.
* **Aprende un idioma** – Selecciona entre inglés, español, francés, italiano
  o alemán.  Evalúa tu nivel y progresa a través de vocabulario, frases,
  gramática y conversación con un chat interactivo.
* **Resuelve un problema** – Introduce o fotografía un problema matemático
  para obtener una solución detallada paso a paso y preguntas de práctica.
* **Internacionalización** – Español e inglés con estructura preparada
  para añadir más idiomas.
* **Enrutamiento con transiciones suaves** – Navegación declarativa con
  GoRouter y transiciones Material (FadeThrough y SharedAxis).
* **Arquitectura limpia y modular** – Separación de funcionalidades en
  módulos (`features`) y utilidades (`core`, `widgets`).
* **Backend seguro** – Lectura de claves a través de variables de entorno y
  proxy para OpenAI (consulta `.env.example`).

## Instalación

1. Clona este repositorio y entra en él.
2. Crea un archivo `.env` o utiliza `env.public` para configurar las
   variables de entorno necesarias.  No compartas claves secretas en el
   cliente.
3. Ejecuta `flutter pub get` para instalar las dependencias.
4. Lanza la aplicación con `flutter run`.

## Estructura

* `lib/core` – Configuraciones y utilidades compartidas como enrutador,
  colores, localización y manejo de entorno.
* `lib/features` – Cada funcionalidad principal (cursos, idiomas, solver)
  tiene su propio subdirectorio con sus vistas.
* `lib/widgets` – Widgets reutilizables (por ejemplo, la app bar).

## I18n

La clase `L10n` contiene un pequeño diccionario de traducciones para
demostrar internacionalización.  Para una solución robusta se recomienda
utilizar las herramientas de generación de localizaciones de Flutter.

## CI/CD

El flujo de trabajo `ci.yml` en `.github/workflows` instala Flutter,
descarga dependencias, analiza el código, ejecuta pruebas unitarias y
realiza un escaneo de secretos con Gitleaks en cada push o pull request.
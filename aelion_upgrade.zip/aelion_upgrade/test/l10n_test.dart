import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:aelion/core/localization.dart';

void main() {
  group('L10n translations', () {
    test('returns Spanish translation by default', () {
      const key = 'ctaCourses';
      // Use a dummy BuildContext by creating a widget and obtaining its context
      final widget = Builder(
        builder: (context) {
          expect(L10n.tr(context, key), 'Toma un curso');
          return const SizedBox.shrink();
        },
      );
      final tester = TestWidgetsFlutterBinding.ensureInitialized();
      // Pump the widget to obtain context
      tester.renderViewElement.update((element) {
        element.mount(
          null,
          null,
        );
      });
    });
  });
}
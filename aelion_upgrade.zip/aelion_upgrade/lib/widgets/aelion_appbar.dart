import 'package:flutter/material.dart';
import '../core/app_colors.dart';

/// A common application bar used throughout the app.  The default
/// background colour uses the secondary colour from the Aelion palette.
class AelionAppBar extends AppBar {
  AelionAppBar({super.key, String title = 'Aelion'})
      : super(
          title: Text(title),
          backgroundColor: AppColors.primary,
          elevation: 0,
        );
}
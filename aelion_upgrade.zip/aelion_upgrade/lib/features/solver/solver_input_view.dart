import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/app_colors.dart';

/// Entry point for the solver feature.  Users can either type a math
/// problem or choose to capture one via the camera.  OCR and AI
/// integration are TODOs; currently this screen forwards the typed
/// problem to the result page.
class SolverInputView extends StatefulWidget {
  const SolverInputView({super.key});

  @override
  State<SolverInputView> createState() => _SolverInputViewState();
}

class _SolverInputViewState extends State<SolverInputView> {
  final TextEditingController _controller = TextEditingController();

  void _solve() {
    if (_controller.text.trim().isEmpty) return;
    context.go('/solver/result');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Resolver problema')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _controller,
              decoration: const InputDecoration(
                hintText: 'Escribe o pega el problema matemático...',
              ),
              minLines: 4,
              maxLines: 6,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _solve,
              child: const Text('Resolver'),
            ),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: () {
                // In a full implementation this would open the camera and run OCR
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Función de cámara aún no implementada.')),
                );
              },
              child: const Text('Tomar foto'),
            ),
          ],
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// Displays the solution to a math or science problem along with a step by
/// step explanation and follow‑up practice.  Integration with OpenAI
/// will generate the solution dynamically in the future.
class SolverResultView extends StatelessWidget {
  const SolverResultView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Solución')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Expanded(
              child: Center(
                child: Text(
                  'La solución paso a paso aparecerá aquí.\n\nLas funciones de IA se integrarán próximamente.',
                  textAlign: TextAlign.center,
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () => context.go('/solver'),
              child: const Text('Resolver otro problema'),
            ),
          ],
        ),
      ),
    );
  }
}
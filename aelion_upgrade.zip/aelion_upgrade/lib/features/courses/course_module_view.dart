import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/app_colors.dart';

/// Displays a course broken down into short modules.  Each card represents
/// a five‑minute lesson.  Completing the final module will navigate to the
/// course results screen.
class CourseModuleView extends StatelessWidget {
  const CourseModuleView({super.key});

  @override
  Widget build(BuildContext context) {
    final modules = [
      {'title': 'Definición', 'description': 'Breve descripción del tema.'},
      {
        'title': 'Ejemplo práctico',
        'description': 'Aplicación real o ejercicio.',
      },
      {
        'title': 'Para profundizar',
        'description': 'Recursos y lecturas recomendadas.',
      },
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Módulo')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: modules.length,
        itemBuilder: (context, index) {
          final section = modules[index];
          return Card(
            color: AppColors.neutral,
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              title: Text(section['title']!),
              subtitle: Text(section['description']!),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () {
                if (index == modules.length - 1) {
                  context.go('/courses/result');
                }
              },
            ),
          );
        },
      ),
    );
  }
}
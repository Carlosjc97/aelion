import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// Final screen of the course flow.  Summarises the learner's progress and
/// offers an option to return home or continue practicing.  In a full
/// implementation this would display analytics and award badges.
class CourseResultView extends StatelessWidget {
  const CourseResultView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Resultados del curso')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Expanded(
              child: Center(
                child: Text(
                  '¡Has completado el curso!\n\nPronto se mostrarán tus estadísticas y logros.',
                  textAlign: TextAlign.center,
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () => context.go('/'),
              child: const Text('Volver al inicio'),
            ),
          ],
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/localization.dart';
import '../../core/app_colors.dart';

/// Initial screen for the course flow.  Allows the user to enter a topic they
/// wish to learn about and presents a few suggestions.  Selecting a topic
/// proceeds to the level selection screen.
class CourseSearchView extends StatelessWidget {
  const CourseSearchView({super.key});

  @override
  Widget build(BuildContext context) {
    final suggestions = [
      'Introducción a Flutter',
      'Historia de Guayaquil',
      'Álgebra básica',
      'Sistemas solares',
    ];
    return Scaffold(
      appBar: AppBar(title: Text(L10n.tr(context, 'ctaCourses'))),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              decoration: InputDecoration(
                hintText: L10n.tr(context, 'searchHint'),
                border: const OutlineInputBorder(),
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: AppColors.neutral,
              ),
              onSubmitted: (value) => context.go('/courses/level'),
            ),
            const SizedBox(height: 16),
            Text(
              L10n.tr(context, 'suggestionsTitle'),
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: AppColors.primary,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: suggestions.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(suggestions[index]),
                    onTap: () => context.go('/courses/level'),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
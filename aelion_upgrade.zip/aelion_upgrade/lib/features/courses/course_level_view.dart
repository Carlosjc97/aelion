import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/localization.dart';
import '../../core/app_colors.dart';

/// Screen that asks the learner for their current level of knowledge.  The
/// selected level is used later to tailor the diagnostic test.  After
/// selecting a level the user can proceed to the diagnostic test screen.
class CourseLevelView extends StatefulWidget {
  const CourseLevelView({super.key});

  @override
  State<CourseLevelView> createState() => _CourseLevelViewState();
}

class _CourseLevelViewState extends State<CourseLevelView> {
  int _selectedLevel = 0; // 0: beginner, 1: intermediate, 2: advanced

  @override
  Widget build(BuildContext context) {
    final levels = [
      'Principiante',
      'Intermedio',
      'Avanzado',
    ];
    return Scaffold(
      appBar: AppBar(title: Text(L10n.tr(context, 'levelSelectTitle'))),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ...List.generate(levels.length, (index) {
              return RadioListTile<int>(
                title: Text(levels[index]),
                value: index,
                groupValue: _selectedLevel,
                onChanged: (value) => setState(() => _selectedLevel = value!),
              );
            }),
            const Spacer(),
            ElevatedButton(
              onPressed: () => context.go('/courses/test'),
              child: const Text('Continuar'),
            ),
          ],
        ),
      ),
    );
  }
}
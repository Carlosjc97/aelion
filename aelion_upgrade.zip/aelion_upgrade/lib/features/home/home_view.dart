import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/app_colors.dart';
import '../../core/localization.dart';

/// The Home view presents the main entry points into the app: courses,
/// languages and solver.  It includes a header, call‑to‑action cards and
/// secondary actions such as searching for a topic or viewing a module
/// example.
class HomeView extends StatelessWidget {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: Text(L10n.tr(context, 'appTitle'))),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final isWide = constraints.maxWidth > 720;
            return SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 820),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Header with emoji logo and subtitle
                      Container(
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: BorderRadius.circular(24),
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 22,
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Text('✨', style: TextStyle(fontSize: 28)),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    L10n.tr(context, 'appTitle'),
                                    style: text.headlineLarge?.copyWith(
                                      color: AppColors.secondary,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    L10n.tr(context, 'homeSubtitle'),
                                    style: text.bodyLarge?.copyWith(
                                      color: const Color(0xFF5A6B80),
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 22),
                      // Primary actions: courses, languages, solver
                      if (isWide)
                        Row(
                          children: [
                            Expanded(
                              child: _CtaCard.primary(
                                title: L10n.tr(context, 'ctaCourses'),
                                emoji: '📚',
                                onTap: () => context.go('/courses'),
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: _CtaCard.primary(
                                title: L10n.tr(context, 'ctaLanguages'),
                                emoji: '🗣️',
                                onTap: () => context.go('/languages'),
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: _CtaCard.primary(
                                title: L10n.tr(context, 'ctaSolver'),
                                emoji: '🔍',
                                onTap: () => context.go('/solver'),
                              ),
                            ),
                          ],
                        )
                      else
                        Column(
                          children: [
                            _CtaCard.primary(
                              title: L10n.tr(context, 'ctaCourses'),
                              emoji: '📚',
                              onTap: () => context.go('/courses'),
                            ),
                            const SizedBox(height: 12),
                            _CtaCard.primary(
                              title: L10n.tr(context, 'ctaLanguages'),
                              emoji: '🗣️',
                              onTap: () => context.go('/languages'),
                            ),
                            const SizedBox(height: 12),
                            _CtaCard.primary(
                              title: L10n.tr(context, 'ctaSolver'),
                              emoji: '🔍',
                              onTap: () => context.go('/solver'),
                            ),
                          ],
                        ),
                      const SizedBox(height: 24),
                      // Secondary actions: search and example links
                      Container(
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: BorderRadius.circular(24),
                        ),
                        padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: TextField(
                                    decoration: InputDecoration(
                                      hintText: L10n.tr(context, 'searchHint'),
                                      prefixIcon: const Icon(Icons.search_rounded),
                                    ),
                                    onSubmitted: (_) => context.go('/courses'),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                FilledButton.icon(
                                  onPressed: () => context.go('/courses'),
                                  icon: const Icon(Icons.search),
                                  label: Text(L10n.tr(context, 'ctaSearchTopic')),
                                ),
                              ],
                            ),
                            const SizedBox(height: 14),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                ActionChip(
                                  avatar: const Text(''),
                                  label: Text(L10n.tr(context, 'ctaSearchTopic')),
                                  onPressed: () => context.go('/courses'),
                                ),
                                ActionChip(
                                  avatar: const Text(''),
                                  label: Text(L10n.tr(context, 'ctaViewExample')),
                                  onPressed: () => context.go('/courses/module'),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

/// Reusable card widget used for the primary call‑to‑action buttons on the
/// home page.  Taps trigger navigation to their respective flows.
class _CtaCard extends StatelessWidget {
  final String title;
  final String emoji;
  final VoidCallback onTap;

  const _CtaCard.primary({
    required this.title,
    required this.emoji,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Ink(
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.neutral),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
        child: Row(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 24)),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                title,
                style: text.titleMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                  color: AppColors.onSurface,
                ),
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: AppColors.onSurface),
          ],
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/localization.dart';

/// Screen for selecting the learner's proficiency in the chosen language.
class LanguageLevelView extends StatefulWidget {
  const LanguageLevelView({super.key});

  @override
  State<LanguageLevelView> createState() => _LanguageLevelViewState();
}

class _LanguageLevelViewState extends State<LanguageLevelView> {
  int _selectedLevel = 0;

  @override
  Widget build(BuildContext context) {
    final levels = ['Principiante', 'Intermedio', 'Avanzado'];
    return Scaffold(
      appBar: AppBar(title: Text(L10n.tr(context, 'levelSelectTitle'))),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ...List.generate(levels.length, (index) {
              return RadioListTile<int>(
                title: Text(levels[index]),
                value: index,
                groupValue: _selectedLevel,
                onChanged: (value) => setState(() => _selectedLevel = value!),
              );
            }),
            const Spacer(),
            ElevatedButton(
              onPressed: () => context.go('/languages/course'),
              child: const Text('Continuar'),
            ),
          ],
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/localization.dart';
import '../../core/app_colors.dart';

/// Allows the user to choose which language they wish to learn.  The selected
/// language will determine the course content downstream.  Each option is
/// represented by its flag and name.
class LanguageSelectionView extends StatelessWidget {
  const LanguageSelectionView({super.key});

  @override
  Widget build(BuildContext context) {
    final languages = [
      {'code': 'en', 'name': 'Inglés', 'emoji': '🇺🇸'},
      {'code': 'es', 'name': 'Español', 'emoji': '🇪🇸'},
      {'code': 'fr', 'name': 'Francés', 'emoji': '🇫🇷'},
      {'code': 'it', 'name': 'Italiano', 'emoji': '🇮🇹'},
      {'code': 'de', 'name': 'Alemán', 'emoji': '🇩🇪'},
    ];
    return Scaffold(
      appBar: AppBar(title: Text(L10n.tr(context, 'languageSelectTitle'))),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: languages.length,
        itemBuilder: (context, index) {
          final lang = languages[index];
          return Card(
            color: AppColors.neutral,
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              leading: Text(lang['emoji']!, style: const TextStyle(fontSize: 28)),
              title: Text(lang['name']!),
              onTap: () => context.go('/languages/level'),
            ),
          );
        },
      ),
    );
  }
}
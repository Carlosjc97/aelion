import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/app_colors.dart';

/// Presents the progression for learning a language.  The flow begins with
/// basic vocabulary and phrases, advances through grammar and concludes
/// with conversation practice.  Selecting the final module opens the chat.
class LanguageCourseView extends StatelessWidget {
  const LanguageCourseView({super.key});

  @override
  Widget build(BuildContext context) {
    final modules = [
      {'title': 'Vocabulario básico', 'description': 'Aprende palabras comunes.'},
      {'title': 'Frases útiles', 'description': 'Práctica de frases diarias.'},
      {'title': 'Gramática', 'description': 'Reglas gramaticales esenciales.'},
      {
        'title': 'Conversación',
        'description': 'Simula conversaciones reales.',
      },
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Curso de idioma')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: modules.length,
        itemBuilder: (context, index) {
          final section = modules[index];
          return Card(
            color: AppColors.neutral,
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              title: Text(section['title']!),
              subtitle: Text(section['description']!),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () {
                if (index == modules.length - 1) {
                  context.go('/languages/chat');
                }
              },
            ),
          );
        },
      ),
    );
  }
}
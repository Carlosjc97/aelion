import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:animations/animations.dart';

import '../features/home/home_view.dart';
import '../features/courses/course_search_view.dart';
import '../features/courses/course_level_view.dart';
import '../features/courses/course_test_view.dart';
import '../features/courses/course_module_view.dart';
import '../features/courses/course_result_view.dart';
import '../features/languages/language_selection_view.dart';
import '../features/languages/language_level_view.dart';
import '../features/languages/language_course_view.dart';
import '../features/languages/language_chat_view.dart';
import '../features/solver/solver_input_view.dart';
import '../features/solver/solver_result_view.dart';
import '../features/splash/splash_view.dart';

/// Centralised routing configuration using GoRouter.  Each route specifies
/// a path, the widget to display and optionally a custom transition.
class AppRouter {
  AppRouter._();

  /// The global router instance used by the MaterialApp.
  static final GoRouter router = GoRouter(
    // Start at the splash screen to display a loading animation before the
    // home screen appears.  When the splash completes it will navigate to '/'.
    initialLocation: '/splash',
    routes: <GoRoute>[
      GoRoute(
        path: '/splash',
        name: 'splash',
        pageBuilder: (context, state) => _buildPageWithFadeThrough(
          context,
          state,
          const SplashView(),
        ),
      ),
      GoRoute(
        path: '/',
        name: 'home',
        pageBuilder: (context, state) => _buildPageWithFadeThrough(
          context,
          state,
          const HomeView(),
        ),
      ),
      // Courses feature
      GoRoute(
        path: '/courses',
        name: 'courses',
        pageBuilder: (context, state) => _buildPageWithFadeThrough(
          context,
          state,
          const CourseSearchView(),
        ),
        routes: [
          GoRoute(
            path: 'level',
            name: 'courseLevel',
            pageBuilder: (context, state) => _buildPageWithSharedAxis(
              context,
              state,
              const CourseLevelView(),
            ),
          ),
          GoRoute(
            path: 'test',
            name: 'courseTest',
            pageBuilder: (context, state) => _buildPageWithSharedAxis(
              context,
              state,
              const CourseTestView(),
            ),
          ),
          GoRoute(
            path: 'module',
            name: 'courseModule',
            pageBuilder: (context, state) => _buildPageWithSharedAxis(
              context,
              state,
              const CourseModuleView(),
            ),
          ),
          GoRoute(
            path: 'result',
            name: 'courseResult',
            pageBuilder: (context, state) => _buildPageWithSharedAxis(
              context,
              state,
              const CourseResultView(),
            ),
          ),
        ],
      ),
      // Languages feature
      GoRoute(
        path: '/languages',
        name: 'languages',
        pageBuilder: (context, state) => _buildPageWithFadeThrough(
          context,
          state,
          const LanguageSelectionView(),
        ),
        routes: [
          GoRoute(
            path: 'level',
            name: 'languageLevel',
            pageBuilder: (context, state) => _buildPageWithSharedAxis(
              context,
              state,
              const LanguageLevelView(),
            ),
          ),
          GoRoute(
            path: 'course',
            name: 'languageCourse',
            pageBuilder: (context, state) => _buildPageWithSharedAxis(
              context,
              state,
              const LanguageCourseView(),
            ),
          ),
          GoRoute(
            path: 'chat',
            name: 'languageChat',
            pageBuilder: (context, state) => _buildPageWithSharedAxis(
              context,
              state,
              const LanguageChatView(),
            ),
          ),
        ],
      ),
      // Solver feature
      GoRoute(
        path: '/solver',
        name: 'solver',
        pageBuilder: (context, state) => _buildPageWithFadeThrough(
          context,
          state,
          const SolverInputView(),
        ),
        routes: [
          GoRoute(
            path: 'result',
            name: 'solverResult',
            pageBuilder: (context, state) => _buildPageWithSharedAxis(
              context,
              state,
              const SolverResultView(),
            ),
          ),
        ],
      ),
    ],
  );

  /// Wraps a child page in a [CustomTransitionPage] that uses a
  /// [FadeThroughTransition] from the animations package.  This provides a
  /// seamless cross fade between routes when navigating between the main
  /// sections of the app.
  static CustomTransitionPage<T> _buildPageWithFadeThrough<T>(
    BuildContext context,
    GoRouterState state,
    Widget child,
  ) {
    return CustomTransitionPage<T>(
      key: state.pageKey,
      child: child,
      transitionsBuilder: (
        context,
        animation,
        secondaryAnimation,
        child,
      ) {
        return FadeThroughTransition(
          animation: animation,
          secondaryAnimation: secondaryAnimation,
          child: child,
        );
      },
    );
  }

  /// Wraps a child page in a [CustomTransitionPage] that uses a
  /// [SharedAxisTransition] from the animations package.  This transition
  /// animates both incoming and outgoing pages along a shared axis and is
  /// suitable for wizard‑style flows such as the level/test progression.
  static CustomTransitionPage<T> _buildPageWithSharedAxis<T>(
    BuildContext context,
    GoRouterState state,
    Widget child,
  ) {
    return CustomTransitionPage<T>(
      key: state.pageKey,
      child: child,
      transitionsBuilder: (
        context,
        animation,
        secondaryAnimation,
        child,
      ) {
        return SharedAxisTransition(
          animation: animation,
          secondaryAnimation: secondaryAnimation,
          child: child,
          transitionType: SharedAxisTransitionType.horizontal,
        );
      },
    );
  }
}
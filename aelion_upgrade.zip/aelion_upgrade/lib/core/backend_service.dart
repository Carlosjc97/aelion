import 'dart:convert';

import 'package:http/http.dart' as http;

import 'env.dart';

/// Simple HTTP client that proxies requests to the backend.  All outgoing
/// requests are prefixed with the `baseUrl` defined in the environment.
class BackendService {
  final _client = http.Client();

  Uri _buildUri(String path, [Map<String, dynamic>? queryParameters]) {
    final base = Env.baseUrl;
    return Uri.parse(base).replace(
      path: '${Uri.parse(base).path}$path',
      queryParameters: queryParameters,
    );
  }

  Future<http.Response> get(String path, {Map<String, dynamic>? params}) async {
    final uri = _buildUri(path, params);
    return _client.get(uri);
  }

  Future<http.Response> post(String path, {Map<String, dynamic>? body}) async {
    final uri = _buildUri(path);
    return _client.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(body ?? {}),
    );
  }

  void dispose() {
    _client.close();
  }
}
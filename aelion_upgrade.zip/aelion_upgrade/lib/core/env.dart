import 'package:flutter_dotenv/flutter_dotenv.dart';

/// Convenience wrapper around the `flutter_dotenv` package to access runtime
/// environment variables.  See `.env.example` for the available keys.
class Env {
  /// Returns the current environment name or 'desconocido' if none is set.
  static String get env => dotenv.isInitialized
      ? dotenv.env['AELION_ENV'] ?? 'desconocido'
      : 'desconocido';

  /// Returns the base URL of the backend proxy (BASE_URL) or an empty string
  /// if not configured.
  static String get baseUrl =>
      dotenv.isInitialized ? dotenv.env['BASE_URL'] ?? '' : '';

  /// Indicates whether a CV_STUDIO_API_KEY has been configured and is not
  /// the default placeholder.  Useful for gating features that depend on
  /// this key.
  static bool get hasCvStudioKey {
    if (!dotenv.isInitialized) return false;
    final key = dotenv.env['CV_STUDIO_API_KEY'] ?? '';
    return key.isNotEmpty && key != 'changeme';
  }
}
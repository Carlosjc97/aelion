import 'package:flutter/material.dart';

/// A very small localisation helper used to demonstrate internationalisation in
/// the Aelion app.  In a production app you would typically use the Flutter
/// localisation tooling (`flutter gen-l10n`) and maintain your strings in
/// ARB files.  Here we manually map language codes to translated strings to
/// avoid requiring code generation during development.
class L10n {
  /// List of locales supported by the app.
  static const supportedLocales = [Locale('es'), Locale('en')];

  /// Hierarchical map of translated values.  The first key is the language
  /// code (e.g. `es`, `en`) and the second key is the string identifier.
  static const Map<String, Map<String, String>> _localizedValues = {
    'es': {
      'appTitle': 'Aelion',
      'homeSubtitle': 'Aprende en minutos, mejora cada día',
      'ctaCourses': 'Toma un curso',
      'ctaLanguages': 'Aprende un idioma',
      'ctaSolver': 'Resuelve un problema',
      'ctaSearchTopic': 'Buscar un tema',
      'ctaViewExample': 'Ver ejemplo de módulo',
      'searchHint': 'Escribe un tema...',
      'suggestionsTitle': 'Sugerencias',
      'languageSelectTitle': 'Selecciona un idioma',
      'levelSelectTitle': 'Selecciona tu nivel',
    },
    'en': {
      'appTitle': 'Aelion',
      'homeSubtitle': 'Learn in minutes, improve every day',
      'ctaCourses': 'Take a course',
      'ctaLanguages': 'Learn a language',
      'ctaSolver': 'Solve a problem',
      'ctaSearchTopic': 'Search a topic',
      'ctaViewExample': 'View module example',
      'searchHint': 'Type a topic...',
      'suggestionsTitle': 'Suggestions',
      'languageSelectTitle': 'Select a language',
      'levelSelectTitle': 'Select your level',
    },
  };

  /// Returns the translated value for the given [key] in the current locale.
  /// If no translation exists for the current locale, falls back to Spanish.
  static String tr(BuildContext context, String key) {
    final locale = Localizations.localeOf(context).languageCode;
    return _localizedValues[locale]?[key] ??
        _localizedValues['es']?[key] ??
        key;
  }
}